import express from 'express';import cors from 'cors';import {createServer} from 'http';import {WebSocketServer} from 'ws';
import {BinanceProvider} from './market-data/binance.js';import {TIMEFRAMES,type Timeframe} from './market-data/types.js';
const provider=new BinanceProvider();
const app=express();
app.use(cors({origin:process.env.CORS_ORIGIN??'http://localhost:5173'}));
const tfOk=(v:any):v is Timeframe=>TIMEFRAMES.includes(v);
const symOk=(v:any):v is string=>typeof v==='string'&&/^[A-Z0-9]{2,20}$/.test(v);
const wrap=(f:(q:any)=>Promise<unknown>)=>async(req:any,res:any)=>{try{res.json(await f(req.query))}catch(e:any){res.status(502).json({error:'DATA UNAVAILABLE',detail:e.message})}};
app.get('/api/health',(_q,r)=>{r.json({ok:true})});
app.get('/api/symbols',wrap(async q=>{
  const s=String(q.q??'').toUpperCase();
  return(await provider.getSymbols()).filter(x=>!s||x.symbol.includes(s)).slice(0,Math.min(Number(q.limit)||50,200));
}));
app.get('/api/candles',wrap(async q=>{
  if(!symOk(q.symbol)||!tfOk(q.tf))throw new Error('Invalid symbol/timeframe');
  return provider.getHistoricalCandles(q.symbol,q.tf,Math.min(Number(q.limit)||500,1000));
}));
app.get('/api/quote',wrap(async q=>{if(!symOk(q.symbol))throw new Error('Invalid symbol');return provider.getQuote(q.symbol)}));
import path from 'path';
const dist=path.resolve(process.cwd(),'frontend/dist');
app.use(express.static(dist));
app.get('*',(_q,r)=>r.sendFile(path.join(dist,'index.html')));
const server=createServer(app);
const wss=new WebSocketServer({server,path:'/stream'});
wss.on('connection',ws=>{
  let sub:string|null=null;let last=0;
  const stop=()=>{if(sub)provider.unsubscribeRealtime(sub);sub=null};
  ws.on('message',m=>{try{const d=JSON.parse(m.toString());
    if(d.type!=='subscribe'||!symOk(d.symbol)||!tfOk(d.tf))return;stop();
    sub=provider.subscribeRealtime(d.symbol,d.tf,c=>{const now=Date.now();
      if(c.closed||now-last>250){last=now;if(ws.readyState===1)ws.send(JSON.stringify({type:'candle',symbol:d.symbol,tf:d.tf,candle:c}))}});
  }catch{}});
  ws.on('close',stop);
});
const port=Number(process.env.PORT)||3001;
server.listen(port,()=>console.log(`API http://localhost:${port}`));
