import WebSocket from 'ws';
import type {Candle,MarketDataProvider,MarketStatus,Quote,SymbolInfo,Timeframe} from './types.js';
const REST='https://api.binance.com/api/v3';
const WS='wss://stream.binance.com:9443/ws';
const j=async(u:string)=>{const r=await fetch(u);if(!r.ok)throw new Error(`Provider ${r.status}`);return r.json() as Promise<any>};
const n=(v:unknown)=>{const x=Number(v);return Number.isFinite(x)?x:null};
export class BinanceProvider implements MarketDataProvider{
  private subs=new Map<string,WebSocket>();
  private cache:{t:number;d:SymbolInfo[]}|null=null;
  async getSymbols(){
    if(this.cache&&Date.now()-this.cache.t<3.6e6)return this.cache.d;
    const d=(await j(`${REST}/exchangeInfo`)).symbols
      .filter((s:any)=>s.status==='TRADING')
      .map((s:any):SymbolInfo=>({symbol:s.symbol,exchange:'BINANCE',assetClass:'CRYPTO',base:s.baseAsset,quote:s.quoteAsset}));
    this.cache={t:Date.now(),d};return d;
  }
  async getHistoricalCandles(symbol:string,tf:Timeframe,limit=500):Promise<Candle[]>{
    const r=await j(`${REST}/klines?symbol=${encodeURIComponent(symbol)}&interval=${tf}&limit=${limit}`);
    const now=Date.now();
    return r.map((k:any[])=>({time:Math.floor(k[0]/1000),open:+k[1],high:+k[2],low:+k[3],close:+k[4],volume:+k[5],closed:k[6]<now}));
  }
  async getLatestPrice(symbol:string){return n((await j(`${REST}/ticker/price?symbol=${encodeURIComponent(symbol)}`)).price)}
  async getQuote(symbol:string):Promise<Quote>{
    const q=await j(`${REST}/ticker/bookTicker?symbol=${encodeURIComponent(symbol)}`);
    const bid=n(q.bidPrice),ask=n(q.askPrice);
    return{symbol,bid,ask,price:bid!==null&&ask!==null?(bid+ask)/2:null,spread:bid!==null&&ask!==null?ask-bid:null,timestamp:Date.now()};
  }
  async getMarketStatus():Promise<MarketStatus>{return 'OPEN'} // crypto 24/7
  subscribeRealtime(symbol:string,tf:Timeframe,cb:(c:Candle)=>void){
    const id=`${symbol}_${tf}_${Math.random().toString(36).slice(2)}`;
    const connect=(attempt=0)=>{
      const ws=new WebSocket(`${WS}/${symbol.toLowerCase()}@kline_${tf}`);
      this.subs.set(id,ws);
      ws.on('message',(m)=>{const k=JSON.parse(m.toString()).k;if(!k)return;
        cb({time:Math.floor(k.t/1000),open:+k.o,high:+k.h,low:+k.l,close:+k.c,volume:+k.v,closed:!!k.x})});
      ws.on('close',()=>{if(this.subs.has(id))setTimeout(()=>connect(attempt+1),Math.min(1000*2**attempt,30000))});
      ws.on('error',()=>ws.close());
    };
    connect();return id;
  }
  unsubscribeRealtime(id:string){const ws=this.subs.get(id);this.subs.delete(id);ws?.close()}
}
