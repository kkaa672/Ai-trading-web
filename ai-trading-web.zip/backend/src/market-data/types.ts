export type Timeframe='1m'|'3m'|'5m'|'15m'|'30m'|'1h'|'2h'|'4h'|'6h'|'12h'|'1d'|'1w'|'1M';
export const TIMEFRAMES:Timeframe[]=['1m','3m','5m','15m','30m','1h','2h','4h','6h','12h','1d','1w','1M'];
export interface Candle{time:number;open:number;high:number;low:number;close:number;volume:number;closed:boolean}
export interface SymbolInfo{symbol:string;exchange:string;assetClass:string;base:string;quote:string}
export interface Quote{symbol:string;price:number|null;bid:number|null;ask:number|null;spread:number|null;timestamp:number}
export type MarketStatus='OPEN'|'CLOSED'|'DATA_UNAVAILABLE';
export interface MarketDataProvider{
  getSymbols():Promise<SymbolInfo[]>;
  getHistoricalCandles(symbol:string,tf:Timeframe,limit?:number):Promise<Candle[]>;
  getLatestPrice(symbol:string):Promise<number|null>;
  getQuote(symbol:string):Promise<Quote>;
  getMarketStatus(symbol:string):Promise<MarketStatus>;
  subscribeRealtime(symbol:string,tf:Timeframe,cb:(c:Candle)=>void):string;
  unsubscribeRealtime(id:string):void;
}
