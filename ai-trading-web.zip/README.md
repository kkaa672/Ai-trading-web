# AI Trading Chart Analyzer — Phase 1
Monorepo: `backend` (Express + WS, TypeScript), `frontend` (React + lightweight-charts).
Data: API publik Binance (crypto, legal, real-time). Provider lain (forex/saham) = implementasi `MarketDataProvider` baru di `backend/src/market-data/`.
## Menjalankan (Node 20+)
    cp .env.example .env
    npm install
    npm run dev -w backend     # terminal 1 → :3001
    npm run dev -w frontend    # terminal 2 → :5173
## Endpoint
GET /api/symbols?q= · GET /api/candles?symbol=&tf= · GET /api/quote?symbol= · WS /stream `{type:"subscribe",symbol,tf}`
## Belum ada (fase berikutnya)
Auth, PostgreSQL, Redis, analysis engine, AI, signal, scan, watchlist, drawing tools, test, Docker.
