import {useEffect,useRef,useState} from 'react';
import {createChart,type IChartApi,type ISeriesApi,type UTCTimestamp} from 'lightweight-charts';
const TFS=['1m','3m','5m','15m','30m','1h','2h','4h','6h','12h','1d','1w','1M'];
const f=(v:number|null|undefined)=>v==null?'N/A':String(v);
export default function App(){
  const box=useRef<HTMLDivElement>(null);const chart=useRef<IChartApi>();const ser=useRef<ISeriesApi<'Candlestick'>>();
  const [symbol,setSymbol]=useState('BTCUSDT');const [tf,setTf]=useState('15m');const [q,setQ]=useState('');
  const [opts,setOpts]=useState<string[]>([]);const [quote,setQuote]=useState<any>(null);const [status,setStatus]=useState('LOADING');
  useEffect(()=>{const c=createChart(box.current!,{layout:{background:{color:'#0b0f14'},textColor:'#d7dde5'},grid:{vertLines:{color:'#151b23'},horzLines:{color:'#151b23'}},autoSize:true,timeScale:{timeVisible:true}});
    chart.current=c;ser.current=c.addCandlestickSeries();return()=>c.remove()},[]);
  useEffect(()=>{if(!q)return;const t=setTimeout(()=>fetch(`/api/symbols?q=${q}`).then(r=>r.json()).then(d=>Array.isArray(d)&&setOpts(d.map((s:any)=>s.symbol))).catch(()=>{}),250);return()=>clearTimeout(t)},[q]);
  useEffect(()=>{let ws:WebSocket|undefined;let dead=false;setStatus('LOADING');
    fetch(`/api/candles?symbol=${symbol}&tf=${tf}`).then(r=>r.ok?r.json():Promise.reject()).then((d:any[])=>{if(dead)return;
      ser.current!.setData(d.map(k=>({time:k.time as UTCTimestamp,open:k.open,high:k.high,low:k.low,close:k.close})));chart.current!.timeScale().fitContent();setStatus('LIVE');
      const open=()=>{ws=new WebSocket(`${location.protocol==='https:'?'wss':'ws'}://${location.host}/stream`);
        ws.onopen=()=>ws!.send(JSON.stringify({type:'subscribe',symbol,tf}));
        ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==='candle'){const k=m.candle;ser.current!.update({time:k.time,open:k.open,high:k.high,low:k.low,close:k.close})}};
        ws.onclose=()=>{if(!dead){setStatus('RECONNECTING');setTimeout(open,2000)}}};open()}).catch(()=>setStatus('DATA UNAVAILABLE'));
    const qt=()=>fetch(`/api/quote?symbol=${symbol}`).then(r=>r.json()).then(setQuote).catch(()=>setQuote(null));qt();const iv=setInterval(qt,3000);
    return()=>{dead=true;ws?.close();clearInterval(iv)}},[symbol,tf]);
  return(<div style={{display:'flex',flexDirection:'column',height:'100vh'}}>
    <div className="bar"><b>{symbol}</b>
      <input list="s" placeholder="Cari symbol…" value={q} onChange={e=>{setQ(e.target.value.toUpperCase());if(opts.includes(e.target.value.toUpperCase()))setSymbol(e.target.value.toUpperCase())}}/>
      <datalist id="s">{opts.map(o=><option key={o} value={o}/>)}</datalist>
      {TFS.map(t=><button key={t} className={t===tf?'on':''} onClick={()=>setTf(t)}>{t}</button>)}<span>{status}</span></div>
    <div className="q"><span>Bid {f(quote?.bid)}</span><span>Ask {f(quote?.ask)}</span><span>Spread {f(quote?.spread)}</span></div>
    <div ref={box} style={{flex:1,minHeight:0}}/></div>);
}
